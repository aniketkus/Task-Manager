# Task Manager

A small full stack Java application built during my **Full Stack Java Development** internship at **The Developers Arena**.

- **Backend:** REST API in plain Java 17+ using the JDK's built-in `com.sun.net.httpserver` (no external libraries)
- **Frontend:** single-page HTML, CSS and vanilla JavaScript served by the same Java app
- **Storage:** tasks are saved to `data/tasks.json`, so they survive restarts

## Features

- Add, complete, and delete tasks
- Filter by All / Active / Done, with a live counter
- Input validation (title required, max 200 characters)
- Proper HTTP status codes (`201`, `204`, `400`, `404`, `405`)

## Project structure

```
task-manager/
├── src/com/taskmanager/
│   ├── Main.java        # HTTP server, routing, REST handlers
│   ├── Task.java        # Task model
│   ├── TaskStore.java   # Thread-safe storage + JSON file persistence
│   └── Json.java        # Small JSON helpers
└── web/index.html       # Frontend
```

## Run it

Requires JDK 17 or newer. From the project root:

```bash
javac -d out src/com/taskmanager/*.java
java -cp out com.taskmanager.Main
```

Then open <http://localhost:8080>. Use a different port with `PORT=9000 java -cp out com.taskmanager.Main`.

## REST API

| Method | Endpoint          | Body                                   | Description        |
|--------|-------------------|----------------------------------------|--------------------|
| GET    | `/api/tasks`      | -                                      | List all tasks     |
| POST   | `/api/tasks`      | `{"title": "Buy milk"}`                | Create a task      |
| PUT    | `/api/tasks/{id}` | `{"done": true}` and/or `{"title": ""}`| Update a task      |
| DELETE | `/api/tasks/{id}` | -                                      | Delete a task      |

Example:

```bash
curl -X POST localhost:8080/api/tasks -d '{"title":"Finish internship report"}'
```

## Author

Aniket Kushwaha
