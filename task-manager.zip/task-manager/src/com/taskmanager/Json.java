package com.taskmanager;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Minimal JSON helpers for flat objects (no external libraries needed). */
public final class Json {
    private static final Pattern FIELD = Pattern.compile(
            "\"([^\"]+)\"\\s*:\\s*(\"(?:\\\\.|[^\"\\\\])*\"|true|false|-?\\d+)");

    private Json() {}

    /** Wraps a string in quotes and escapes special characters. */
    public static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    /** Reverses {@link #quote(String)} for a quoted JSON string value. */
    private static String unquote(String raw) {
        String s = raw.substring(1, raw.length() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (i + 4 < s.length()) {
                            sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                            i += 4;
                        }
                        break;
                    default: sb.append(n);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Parses a flat JSON object into a key/value map (values are plain strings). */
    public static Map<String, String> parseFlat(String json) {
        Map<String, String> map = new HashMap<>();
        Matcher m = FIELD.matcher(json);
        while (m.find()) {
            String v = m.group(2);
            map.put(m.group(1), v.startsWith("\"") ? unquote(v) : v);
        }
        return map;
    }
}
