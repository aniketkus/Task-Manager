package com.taskmanager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Thread-safe task storage that persists to a JSON file. */
public class TaskStore {
    private final Path file;
    private final List<Task> tasks = new ArrayList<>();
    private long nextId = 1;

    public TaskStore(Path file) {
        this.file = file;
        load();
    }

    public synchronized List<Task> all() {
        return new ArrayList<>(tasks);
    }

    public synchronized Task add(String title) {
        Task t = new Task(nextId++, title, false, Instant.now().toString());
        tasks.add(t);
        save();
        return t;
    }

    /** Updates title and/or done flag. Returns null if the task does not exist. */
    public synchronized Task update(long id, String title, Boolean done) {
        for (Task t : tasks) {
            if (t.getId() == id) {
                if (title != null) t.setTitle(title);
                if (done != null) t.setDone(done);
                save();
                return t;
            }
        }
        return null;
    }

    public synchronized boolean delete(long id) {
        boolean removed = tasks.removeIf(t -> t.getId() == id);
        if (removed) save();
        return removed;
    }

    private void save() {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < tasks.size(); i++) {
            sb.append("  ").append(tasks.get(i).toJson());
            sb.append(i < tasks.size() - 1 ? ",\n" : "\n");
        }
        sb.append("]\n");
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            Files.write(file, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Could not save tasks: " + e.getMessage());
        }
    }

    private void load() {
        if (!Files.exists(file)) return;
        try {
            String content = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            Matcher m = Pattern.compile("\\{[^{}]*\\}").matcher(content);
            while (m.find()) {
                Map<String, String> f = Json.parseFlat(m.group());
                long id = Long.parseLong(f.get("id"));
                tasks.add(new Task(id, f.get("title"), Boolean.parseBoolean(f.get("done")), f.get("createdAt")));
                nextId = Math.max(nextId, id + 1);
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("Could not read " + file + ": " + e.getMessage());
        }
    }
}
