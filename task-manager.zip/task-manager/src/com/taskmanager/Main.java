package com.taskmanager;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

/**
 * Task Manager - a small full stack Java app.
 * Backend: REST API built on the JDK's built-in HTTP server.
 * Frontend: static HTML/CSS/JS served from the web/ folder.
 */
public class Main {
    private static final String API = "/api/tasks";
    private static final int MAX_TITLE = 200;

    private static TaskStore store;
    private static Path indexFile;

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        store = new TaskStore(Paths.get("data", "tasks.json"));
        indexFile = Paths.get("web", "index.html");

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext(API, Main::handleApi);
        server.createContext("/", Main::handleStatic);
        server.start();
        System.out.println("Task Manager running at http://localhost:" + port);
    }

    // ---------- Static frontend ----------
    private static void handleStatic(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        if (!"GET".equals(ex.getRequestMethod()) || !(path.equals("/") || path.equals("/index.html"))) {
            send(ex, 404, "text/plain; charset=utf-8", "Not found");
            return;
        }
        if (!Files.exists(indexFile)) {
            send(ex, 500, "text/plain; charset=utf-8", "web/index.html not found. Run the app from the project root.");
            return;
        }
        send(ex, 200, "text/html; charset=utf-8", new String(Files.readAllBytes(indexFile), StandardCharsets.UTF_8));
    }

    // ---------- REST API ----------
    private static void handleApi(HttpExchange ex) throws IOException {
        try {
            String method = ex.getRequestMethod();
            String path = ex.getRequestURI().getPath();
            String rest = path.length() > API.length() ? path.substring(API.length() + 1) : "";

            if (rest.isEmpty()) {
                if ("GET".equals(method)) {
                    listTasks(ex);
                } else if ("POST".equals(method)) {
                    createTask(ex);
                } else {
                    json(ex, 405, error("Method not allowed"));
                }
                return;
            }

            long id;
            try {
                id = Long.parseLong(rest);
            } catch (NumberFormatException e) {
                json(ex, 400, error("Invalid task id"));
                return;
            }

            if ("PUT".equals(method)) {
                updateTask(ex, id);
            } else if ("DELETE".equals(method)) {
                if (store.delete(id)) send(ex, 204, "application/json", "");
                else json(ex, 404, error("Task not found"));
            } else {
                json(ex, 405, error("Method not allowed"));
            }
        } catch (RuntimeException e) {
            json(ex, 500, error("Server error"));
        }
    }

    private static void listTasks(HttpExchange ex) throws IOException {
        List<Task> tasks = store.all();
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < tasks.size(); i++) {
            sb.append(tasks.get(i).toJson());
            if (i < tasks.size() - 1) sb.append(",");
        }
        json(ex, 200, sb.append("]").toString());
    }

    private static void createTask(HttpExchange ex) throws IOException {
        Map<String, String> body = Json.parseFlat(readBody(ex));
        String title = body.get("title") == null ? "" : body.get("title").trim();
        if (title.isEmpty() || title.length() > MAX_TITLE) {
            json(ex, 400, error("Title is required (max " + MAX_TITLE + " characters)"));
            return;
        }
        json(ex, 201, store.add(title).toJson());
    }

    private static void updateTask(HttpExchange ex, long id) throws IOException {
        Map<String, String> body = Json.parseFlat(readBody(ex));
        String title = body.containsKey("title") ? body.get("title").trim() : null;
        if (title != null && (title.isEmpty() || title.length() > MAX_TITLE)) {
            json(ex, 400, error("Title must be 1-" + MAX_TITLE + " characters"));
            return;
        }
        Boolean done = body.containsKey("done") ? Boolean.valueOf(body.get("done")) : null;
        Task t = store.update(id, title, done);
        if (t == null) json(ex, 404, error("Task not found"));
        else json(ex, 200, t.toJson());
    }

    // ---------- Helpers ----------
    private static String error(String message) {
        return "{\"error\":" + Json.quote(message) + "}";
    }

    private static String readBody(HttpExchange ex) throws IOException {
        return new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private static void json(HttpExchange ex, int status, String body) throws IOException {
        send(ex, status, "application/json; charset=utf-8", body);
    }

    private static void send(HttpExchange ex, int status, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type);
        if (status == 204) {
            ex.sendResponseHeaders(status, -1);
        } else {
            ex.sendResponseHeaders(status, bytes.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(bytes);
            }
        }
        ex.close();
    }
}
