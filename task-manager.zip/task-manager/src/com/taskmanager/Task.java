package com.taskmanager;

/** A single to-do item. */
public class Task {
    private final long id;
    private String title;
    private boolean done;
    private final String createdAt;

    public Task(long id, String title, boolean done, String createdAt) {
        this.id = id;
        this.title = title;
        this.done = done;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public String getTitle() { return title; }
    public boolean isDone() { return done; }
    public String getCreatedAt() { return createdAt; }

    public void setTitle(String title) { this.title = title; }
    public void setDone(boolean done) { this.done = done; }

    /** Serialises this task to a JSON object string. */
    public String toJson() {
        return "{\"id\":" + id
                + ",\"title\":" + Json.quote(title)
                + ",\"done\":" + done
                + ",\"createdAt\":" + Json.quote(createdAt) + "}";
    }
}
